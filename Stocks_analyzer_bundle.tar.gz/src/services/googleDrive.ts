export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  modifiedTime?: string;
  webViewLink?: string;
}

/**
 * Searches Google Drive for files matching a query string
 */
export async function searchDriveFiles(
  accessToken: string,
  query: string
): Promise<DriveFileItem[]> {
  const url = new URL('https://www.googleapis.com/drive/v3/files');
  url.searchParams.set('q', query);
  url.searchParams.set(
    'fields',
    'files(id, name, mimeType, size, modifiedTime, webViewLink)'
  );
  url.searchParams.set('pageSize', '30');
  url.searchParams.set('orderBy', 'modifiedTime desc');

  const response = await fetch(url.toString(), {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Accept: 'application/json',
    },
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Google Drive API error (${response.status}): ${errText}`);
  }

  const data = await response.json();
  return data.files || [];
}

/**
 * Specifically attempts to find "All equity details.csv" in user's Drive
 */
export async function findTargetEquityFile(accessToken: string): Promise<DriveFileItem | null> {
  // First, check exact name
  try {
    const exactQuery = "name = 'All equity details.csv' and trashed = false";
    const exactMatches = await searchDriveFiles(accessToken, exactQuery);
    if (exactMatches.length > 0) {
      return exactMatches[0];
    }

    // Second, check case-insensitive / partial name
    const partialQuery = "name contains 'equity' and trashed = false";
    const partialMatches = await searchDriveFiles(accessToken, partialQuery);
    const csvOrDetails = partialMatches.find(
      (f) =>
        f.name.toLowerCase().includes('all equity') ||
        (f.name.toLowerCase().includes('equity') && f.name.toLowerCase().endsWith('.csv'))
    );
    if (csvOrDetails) {
      return csvOrDetails;
    }

    // Third, check any csv files
    const allCsvQuery = "trashed = false and (mimeType = 'text/csv' or name contains '.csv')";
    const csvs = await searchDriveFiles(accessToken, allCsvQuery);
    const equityNamed = csvs.find((f) => f.name.toLowerCase().includes('equity'));
    if (equityNamed) {
      return equityNamed;
    }

    return null;
  } catch (error) {
    console.error('Error finding target equity file in Drive:', error);
    return null;
  }
}

/**
 * List all CSV files available in user's Google Drive
 */
export async function listDriveCsvFiles(
  accessToken: string,
  searchTerm?: string
): Promise<DriveFileItem[]> {
  let query = "trashed = false and (mimeType = 'text/csv' or mimeType = 'text/plain' or name contains '.csv')";
  if (searchTerm && searchTerm.trim()) {
    const cleanSearch = searchTerm.replace(/'/g, "\\'");
    query += ` and name contains '${cleanSearch}'`;
  }
  return searchDriveFiles(accessToken, query);
}

/**
 * Download raw file content as text from Google Drive
 */
export async function downloadFileContent(
  accessToken: string,
  fileId: string
): Promise<string> {
  const url = `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(
    fileId
  )}?alt=media`;

  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Failed to download file from Drive (${response.status}): ${errText}`);
  }

  return await response.text();
}
