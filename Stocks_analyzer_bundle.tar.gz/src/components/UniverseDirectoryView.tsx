import React, { useState, useMemo } from 'react';
import {
  Database,
  Search,
  Filter,
  ArrowUpDown,
  ChevronRight,
  PieChart,
  Layers,
  Building2,
} from 'lucide-react';
import { StockEquity, MarketCapTier } from '../types/equity';

interface Props {
  stocks: StockEquity[];
  selectedCapTier: MarketCapTier | 'ALL';
  onSelectCapTier: (tier: MarketCapTier | 'ALL') => void;
  onInspectStock: (symbol: string) => void;
}

export const UniverseDirectoryView: React.FC<Props> = ({
  stocks,
  selectedCapTier,
  onSelectCapTier,
  onInspectStock,
}) => {
  const [selectedSector, setSelectedSector] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortField, setSortField] = useState<keyof StockEquity>('marketCapRank');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Sectors list
  const sectors = useMemo(() => {
    const set = new Set<string>();
    stocks.forEach((s) => set.add(s.sector));
    return Array.from(set).sort();
  }, [stocks]);

  // Sector breakdown stats
  const sectorCounts = useMemo(() => {
    const map: Record<string, number> = {};
    stocks.forEach((s) => {
      map[s.sector] = (map[s.sector] || 0) + 1;
    });
    return map;
  }, [stocks]);

  const filteredStocks = useMemo(() => {
    return stocks.filter((s) => {
      if (selectedCapTier !== 'ALL' && s.capTier !== selectedCapTier) return false;
      if (selectedSector !== 'ALL' && s.sector !== selectedSector) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        if (!s.symbol.toLowerCase().includes(q) && !s.companyName.toLowerCase().includes(q)) {
          return false;
        }
      }
      return true;
    });
  }, [stocks, selectedCapTier, selectedSector, searchQuery]);

  const sortedStocks = useMemo(() => {
    return [...filteredStocks].sort((a, b) => {
      const valA = (a[sortField] as any) ?? -Infinity;
      const valB = (b[sortField] as any) ?? -Infinity;
      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredStocks, sortField, sortDirection]);

  const handleSort = (field: keyof StockEquity) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[11px] font-bold tracking-wide uppercase bg-slate-800 text-slate-300 border border-slate-700">
                Universe Master
              </span>
              <h2 className="text-xl font-bold text-white">
                Selected Research Universe ({stocks.length.toLocaleString('en-IN')} Indian Stocks)
              </h2>
            </div>
            <p className="text-slate-400 text-sm mt-1">
              Authoritative classification registry segmented into High-Cap, Mid-Cap, and Low-Cap corresponding to <code className="text-indigo-400 text-xs font-mono">ALL EQUITY DETAILS.CSV</code> and Parquet tiers <code className="text-indigo-400 text-xs font-mono">01_HIGH</code>, <code className="text-indigo-400 text-xs font-mono">02_MID</code>, and <code className="text-indigo-400 text-xs font-mono">03_LOW</code>.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Total Tracked:</span>
            <span className="text-sm font-bold text-white bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
              {stocks.length.toLocaleString('en-IN')} Equities
            </span>
          </div>
        </div>

        {/* Cap Tier Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 pt-4 border-t border-slate-800">
          <div
            onClick={() => onSelectCapTier('HIGH')}
            className={`p-3 rounded-lg border cursor-pointer transition-all ${
              selectedCapTier === 'HIGH'
                ? 'bg-indigo-950/80 border-indigo-500 shadow-sm'
                : 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800/70'
            }`}
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-indigo-300">01_HIGH_CAP (Top ~100)</span>
              <span className="text-[10px] bg-indigo-900/60 text-indigo-300 px-1.5 py-0.5 rounded">
                Tier 1
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Large-cap bellwethers (Reliance, TCS, HDFC Bank, Infosys, etc.)
            </p>
          </div>

          <div
            onClick={() => onSelectCapTier('MID')}
            className={`p-3 rounded-lg border cursor-pointer transition-all ${
              selectedCapTier === 'MID'
                ? 'bg-amber-950/80 border-amber-500 shadow-sm'
                : 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800/70'
            }`}
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-amber-300">02_MID_CAP (~350 stocks)</span>
              <span className="text-[10px] bg-amber-900/60 text-amber-300 px-1.5 py-0.5 rounded">
                Tier 2
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Mid-cap growth &amp; sectoral leaders (Trent, Polycab, Persistent, Dixon)
            </p>
          </div>

          <div
            onClick={() => onSelectCapTier('LOW')}
            className={`p-3 rounded-lg border cursor-pointer transition-all ${
              selectedCapTier === 'LOW'
                ? 'bg-slate-800 border-slate-500 shadow-sm'
                : 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800/70'
            }`}
          >
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-200">03_LOW_CAP (~670 stocks)</span>
              <span className="text-[10px] bg-slate-700 text-slate-300 px-1.5 py-0.5 rounded">
                Tier 3
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              Small/micro-caps (Cyient, Route Mobile, CDSL, Angel One, CAMS)
            </p>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3 flex-wrap">
          {/* Search */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search symbol or company..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-slate-200 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 w-56"
            />
          </div>

          {/* Sector Filter */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Sector:</span>
            <select
              value={selectedSector}
              onChange={(e) => setSelectedSector(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Sectors ({sectors.length})</option>
              {sectors.map((s) => (
                <option key={s} value={s}>
                  {s} ({sectorCounts[s] || 0})
                </option>
              ))}
            </select>
          </div>

          {/* Tier Filter */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Tier:</span>
            <select
              value={selectedCapTier}
              onChange={(e) => onSelectCapTier(e.target.value as any)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
            >
              <option value="ALL">All Tiers</option>
              <option value="HIGH">High-Cap Only</option>
              <option value="MID">Mid-Cap Only</option>
              <option value="LOW">Low-Cap Only</option>
            </select>
          </div>
        </div>

        <div className="text-xs text-slate-400">
          Showing <strong className="text-white">{sortedStocks.length}</strong> of {stocks.length} stocks
        </div>
      </div>

      {/* Stocks Directory Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/80 text-slate-400 uppercase tracking-wider font-semibold border-b border-slate-700">
              <tr>
                <th
                  className="py-3 px-4 cursor-pointer hover:text-white"
                  onClick={() => handleSort('marketCapRank')}
                >
                  <div className="flex items-center gap-1">
                    <span>Rank</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-3">Symbol & Company</th>
                <th className="py-3 px-3">Tier</th>
                <th className="py-3 px-3">Sector</th>
                <th className="py-3 px-3">Industry</th>
                <th
                  className="py-3 px-3 cursor-pointer hover:text-white"
                  onClick={() => handleSort('currentPrice')}
                >
                  <div className="flex items-center gap-1">
                    <span>Reference Price</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  className="py-3 px-3 cursor-pointer hover:text-white"
                  onClick={() => handleSort('peRatio')}
                >
                  <div className="flex items-center gap-1">
                    <span>P/E</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  className="py-3 px-3 cursor-pointer hover:text-white"
                  onClick={() => handleSort('roePercent')}
                >
                  <div className="flex items-center gap-1">
                    <span>ROE %</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="py-3 px-3">Market Cap</th>
                <th className="py-3 px-3 text-right">Research</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {sortedStocks.slice(0, 60).map((s) => (
                <tr key={s.symbol} className="hover:bg-slate-800/50 transition-colors">
                  <td className="py-2.5 px-4 font-mono text-slate-400">#{s.marketCapRank}</td>
                  <td className="py-2.5 px-3">
                    <div className="font-mono font-bold text-white">{s.symbol}</div>
                    <div className="text-[11px] text-slate-400 truncate max-w-[160px]">
                      {s.companyName}
                    </div>
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        s.capTier === 'HIGH'
                          ? 'bg-indigo-950 text-indigo-300 border border-indigo-800/60'
                          : s.capTier === 'MID'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800/60'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {s.capTier}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300">{s.sector}</td>
                  <td className="py-2.5 px-3 text-slate-400 text-[11px] truncate max-w-[140px]">
                    {s.industry}
                  </td>
                  <td className="py-2.5 px-3 font-mono font-medium text-white">
                    ₹{s.currentPrice?.toLocaleString('en-IN') || '—'}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-300">
                    {s.peRatio ? `${s.peRatio}x` : '—'}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-300">
                    {s.roePercent ? `${s.roePercent}%` : '—'}
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 font-mono text-[11px]">
                    {s.marketCap || '—'}
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={() => onInspectStock(s.symbol)}
                      className="text-xs text-indigo-400 hover:text-indigo-300 font-medium hover:underline inline-flex items-center gap-0.5 cursor-pointer"
                    >
                      Deep-Dive <ChevronRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {sortedStocks.length > 60 && (
          <div className="p-3 bg-slate-800/60 border-t border-slate-800 text-center text-xs text-slate-400">
            Showing top 60 of {sortedStocks.length} stocks. Use search or sector filters to view specific segments.
          </div>
        )}
      </div>
    </div>
  );
};
