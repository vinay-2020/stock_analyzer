import React, { useRef, useState } from 'react';
import {
  Database,
  Upload,
  FileCheck,
  AlertCircle,
  HardDrive,
  Info,
  CheckCircle2,
  Filter,
} from 'lucide-react';
import { MarketCapTier, FileMetadataState } from '../types/equity';
import { parseParquetBuffer, ParquetParseResult } from '../services/parquetLoader';

interface Props {
  totalStocks: number;
  highCapCount: number;
  midCapCount: number;
  lowCapCount: number;
  fileMetadata: FileMetadataState;
  onParquetParsed: (result: ParquetParseResult) => void;
  onCsvLoaded: (file: File) => void;
  selectedCapTier: MarketCapTier | 'ALL';
  onSelectCapTier: (tier: MarketCapTier | 'ALL') => void;
}

export const HistoricalDataSourceBar: React.FC<Props> = ({
  totalStocks,
  highCapCount,
  midCapCount,
  lowCapCount,
  fileMetadata,
  onParquetParsed,
  onCsvLoaded,
  selectedCapTier,
  onSelectCapTier,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [parseStatus, setParseStatus] = useState<string | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const isParquet = file.name.toLowerCase().endsWith('.parquet');
    const isCsv = file.name.toLowerCase().endsWith('.csv');

    if (isParquet) {
      setIsParsing(true);
      setParseStatus(`Reading Parquet file: ${file.name}...`);
      try {
        const buffer = await file.arrayBuffer();
        const result = await parseParquetBuffer(buffer, file.name);
        onParquetParsed(result);
        if (result.error) {
          setParseStatus(`Error: ${result.error}`);
        } else {
          setParseStatus(`Successfully parsed ${result.rowCount.toLocaleString('en-IN')} records from ${file.name}`);
        }
      } catch (err: any) {
        setParseStatus(`Failed to read file: ${err?.message || 'Unknown error'}`);
      } finally {
        setIsParsing(false);
      }
    } else if (isCsv) {
      onCsvLoaded(file);
      setParseStatus(`Loaded CSV file: ${file.name}`);
    } else {
      setParseStatus(`Unsupported file format. Please provide .parquet or .csv file.`);
    }
  };

  return (
    <div className="bg-slate-900 border-b border-slate-800 text-slate-100">
      {/* Principle & Disclaimer Header Strip */}
      <div className="bg-indigo-950/60 border-b border-indigo-900/40 px-4 py-2 text-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-indigo-300 font-medium">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>CORE PRINCIPLE:</span>
          <span className="text-white font-semibold">CODE CALCULATES. AI INTERPRETS.</span>
          <span className="text-slate-400 hidden sm:inline">— Deterministic Historical Research Engine (NSE/BSE)</span>
        </div>
        <div className="flex items-center gap-4 text-slate-400">
          <span className="flex items-center gap-1 text-amber-300">
            <Info className="w-3.5 h-3.5" />
            Strictly Historical • Zero Speculative Guesswork • No Buy/Sell Advice
          </span>
          <span className="text-slate-500">|</span>
          <span className="text-slate-300 font-mono">Currency: INR (₹)</span>
        </div>
      </div>

      {/* Universe & Ingestion Control Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 flex flex-wrap items-center justify-between gap-4">
        {/* Universe Size & Cap Tier Segmentation */}
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                Research Universe
              </div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span>{totalStocks.toLocaleString('en-IN')} Indian Stocks</span>
                <span className="text-xs font-normal text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-1.5 py-0.5 rounded">
                  NSE/BSE Listed
                </span>
              </div>
            </div>
          </div>

          {/* Tier Pills */}
          <div className="flex items-center bg-slate-800/80 p-1 rounded-lg border border-slate-700/60 text-xs">
            <button
              onClick={() => onSelectCapTier('ALL')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                selectedCapTier === 'ALL'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Tiers ({totalStocks})
            </button>
            <button
              onClick={() => onSelectCapTier('HIGH')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                selectedCapTier === 'HIGH'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Large Cap (Top ~100 by Market Cap) - 01_STOCKS_MARKETCAP_HIGH.parquet"
            >
              High-Cap ({highCapCount})
            </button>
            <button
              onClick={() => onSelectCapTier('MID')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                selectedCapTier === 'MID'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Mid Cap (~350 stocks) - 02_STOCKS_MARKETCAP_MID.parquet"
            >
              Mid-Cap ({midCapCount})
            </button>
            <button
              onClick={() => onSelectCapTier('LOW')}
              className={`px-2.5 py-1 rounded font-medium transition-colors ${
                selectedCapTier === 'LOW'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Small/Micro Cap (~670 stocks) - 03_STOCKS_MARKETCAP_LOW.parquet"
            >
              Low-Cap ({lowCapCount})
            </button>
          </div>
        </div>

        {/* Source File Actions */}
        <div className="flex items-center gap-3">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".parquet,.csv"
            className="hidden"
          />

          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isParsing}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 transition-colors cursor-pointer shadow-sm hover:border-slate-600"
            title="Upload 01_STOCKS_MARKETCAP_HIGH.parquet, 02_STOCKS_MARKETCAP_MID.parquet, or 03_STOCKS_MARKETCAP_LOW.parquet"
          >
            <Upload className="w-3.5 h-3.5 text-indigo-400" />
            {isParsing ? 'Parsing Parquet...' : 'Upload Parquet / CSV File'}
          </button>

          <div className="hidden lg:flex items-center gap-2 text-xs text-slate-400 bg-slate-800/50 px-2.5 py-1.5 rounded-md border border-slate-700/40">
            <FileCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Dataset: <strong className="text-slate-200">{fileMetadata.fileName}</strong></span>
            <span className="text-slate-500 font-mono">({fileMetadata.rowCount.toLocaleString('en-IN')} records)</span>
          </div>
        </div>
      </div>

      {/* Parse Feedback Notification */}
      {parseStatus && (
        <div className="bg-slate-800 border-t border-slate-700/50 px-4 py-1.5 text-xs text-slate-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>{parseStatus}</span>
          </div>
          <button
            onClick={() => setParseStatus(null)}
            className="text-slate-400 hover:text-slate-200 text-xs underline ml-4 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}
    </div>
  );
};
