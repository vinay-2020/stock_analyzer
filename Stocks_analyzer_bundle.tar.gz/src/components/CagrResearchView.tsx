import React, { useState, useMemo } from 'react';
import {
  TrendingUp,
  Search,
  Filter,
  Layers,
  Building2,
  PieChart,
  Download,
  Info,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { StockEquity, StockCagrRecord, SectorCagrRecord, IndustryCagrRecord } from '../types/equity';
import {
  buildStockCagrDataset,
  calculateSectorCagrDataset,
  calculateIndustryCagrDataset,
} from '../engine/quantitativeMath';

interface CagrResearchViewProps {
  stocks: StockEquity[];
  onInspectStock: (symbol: string) => void;
  onExportDriveJson?: () => void;
}

export const CagrResearchView: React.FC<CagrResearchViewProps> = ({
  stocks,
  onInspectStock,
  onExportDriveJson,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'stocks' | 'sectors' | 'industries'>('stocks');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedHorizon, setSelectedHorizon] = useState<'5Y' | '3Y' | '10Y' | '15Y'>('5Y');
  const [selectedSectorFilter, setSelectedSectorFilter] = useState<string>('ALL');
  const [onlyNifty50, setOnlyNifty50] = useState<boolean>(false);

  // Compute structured datasets deterministically
  const stocksCagr = useMemo(() => buildStockCagrDataset(stocks), [stocks]);
  const sectorCagr = useMemo(() => calculateSectorCagrDataset(stocks, stocksCagr), [stocks, stocksCagr]);
  const industryCagr = useMemo(() => calculateIndustryCagrDataset(stocks, stocksCagr), [stocks, stocksCagr]);

  // Unique sector names for filter dropdown
  const sectorNames = useMemo(() => {
    return Array.from(new Set(stocks.map((s) => s.sector))).sort();
  }, [stocks]);

  // Filtered Stocks CAGR
  const filteredStocks = useMemo(() => {
    return stocksCagr.filter((item) => {
      const matchesSearch =
        item.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.sector.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.industry.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesSector =
        selectedSectorFilter === 'ALL' || item.sector === selectedSectorFilter;

      const matchesNifty50 = !onlyNifty50 || (item.marketCapRank && item.marketCapRank <= 50);

      return matchesSearch && matchesSector && matchesNifty50;
    });
  }, [stocksCagr, searchQuery, selectedSectorFilter, onlyNifty50]);

  // Filtered Sectors
  const filteredSectors = useMemo(() => {
    return sectorCagr.filter((s) =>
      s.sector.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [sectorCagr, searchQuery]);

  // Filtered Industries
  const filteredIndustries = useMemo(() => {
    return industryCagr.filter(
      (ind) =>
        (ind.industry.toLowerCase().includes(searchQuery.toLowerCase()) ||
          ind.sector.toLowerCase().includes(searchQuery.toLowerCase())) &&
        (selectedSectorFilter === 'ALL' || ind.sector === selectedSectorFilter)
    );
  }, [industryCagr, searchQuery, selectedSectorFilter]);

  return (
    <div className="space-y-6">
      {/* Top Banner / Mission Statement */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 text-xs font-semibold rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60">
                DETERMINISTIC QUANTITATIVE RESEARCH
              </span>
              <span className="text-xs text-slate-400">15Y / 10Y / 5Y / 3Y Horizon Matrices</span>
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-emerald-400" />
              Historical Compound Annual Growth Rate (CAGR) Engine
            </h1>
            <p className="text-slate-400 text-sm mt-1 max-w-3xl">
              Deterministic historical CAGR compounding engine. Sector CAGR evaluates the <strong>Top 50 companies</strong> by market cap. Industry CAGR evaluates the <strong>Top 25 constituents</strong> with mandatory sample size disclosures ($n$).
            </p>
          </div>

          <div className="flex items-center gap-3">
            {onExportDriveJson && (
              <button
                onClick={onExportDriveJson}
                className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-sm font-medium rounded-lg border border-slate-700 transition"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                Export Structured DB
              </button>
            )}
          </div>
        </div>

        {/* Sub-tab switcher */}
        <div className="flex items-center gap-2 mt-6 pt-4 border-t border-slate-800">
          <button
            onClick={() => setActiveSubTab('stocks')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition flex items-center gap-2 ${
              activeSubTab === 'stocks'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-800/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Building2 className="w-4 h-4" />
            Stock-Level CAGR ({filteredStocks.length})
          </button>
          <button
            onClick={() => setActiveSubTab('sectors')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition flex items-center gap-2 ${
              activeSubTab === 'sectors'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-800/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <PieChart className="w-4 h-4" />
            Sector Top 50 CAGR ({filteredSectors.length})
          </button>
          <button
            onClick={() => setActiveSubTab('industries')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition flex items-center gap-2 ${
              activeSubTab === 'industries'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-800/60 text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            Industry Top 25 CAGR ({filteredIndustries.length})
          </button>
        </div>
      </div>

      {/* Filter and Control Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={
                activeSubTab === 'stocks'
                  ? 'Search symbol, company, sector...'
                  : activeSubTab === 'sectors'
                  ? 'Search sector name...'
                  : 'Search industry or sector...'
              }
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          {(activeSubTab === 'stocks' || activeSubTab === 'industries') && (
            <select
              value={selectedSectorFilter}
              onChange={(e) => setSelectedSectorFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-300 focus:outline-none focus:border-emerald-500"
            >
              <option value="ALL">All Sectors (18)</option>
              {sectorNames.map((sec) => (
                <option key={sec} value={sec}>
                  {sec}
                </option>
              ))}
            </select>
          )}

          {activeSubTab === 'stocks' && (
            <button
              onClick={() => setOnlyNifty50(!onlyNifty50)}
              className={`px-3 py-2 text-xs font-semibold rounded-lg border transition ${
                onlyNifty50
                  ? 'bg-emerald-950 text-emerald-400 border-emerald-700'
                  : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
              }`}
            >
              NIFTY 50 Only
            </button>
          )}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium">Primary Horizon:</span>
          {(['5Y', '3Y', '10Y', '15Y'] as const).map((hz) => (
            <button
              key={hz}
              onClick={() => setSelectedHorizon(hz)}
              className={`px-2.5 py-1 text-xs font-bold rounded ${
                selectedHorizon === hz
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              {hz}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: STOCK-LEVEL CAGR TABLE */}
      {activeSubTab === 'stocks' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-950/80 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Symbol / Company</th>
                  <th className="py-3.5 px-4">Sector & Industry</th>
                  <th className="py-3.5 px-3 text-center">Cap Tier</th>
                  <th className="py-3.5 px-3 text-right">Price</th>
                  <th className="py-3.5 px-4 text-right">3Y CAGR</th>
                  <th className="py-3.5 px-4 text-right bg-emerald-950/20 text-emerald-400 font-bold">5Y CAGR</th>
                  <th className="py-3.5 px-4 text-right">10Y CAGR</th>
                  <th className="py-3.5 px-4 text-right">15Y CAGR</th>
                  <th className="py-3.5 px-4 text-center">Horizon Status</th>
                  <th className="py-3.5 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredStocks.slice(0, 100).map((row) => (
                  <tr key={row.symbol} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4">
                      <div className="font-mono font-bold text-white flex items-center gap-1.5">
                        {row.symbol}
                        {row.marketCapRank && row.marketCapRank <= 50 && (
                          <span className="px-1.5 py-0.2 text-[10px] bg-blue-900/60 text-blue-300 rounded border border-blue-700/50">
                            NIFTY50
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400 truncate max-w-[180px]">{row.companyName}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-xs font-medium text-slate-300">{row.sector}</div>
                      <div className="text-[11px] text-slate-500 truncate max-w-[180px]">{row.industry}</div>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`px-2 py-0.5 text-[11px] font-bold rounded ${
                          row.capTier === 'HIGH'
                            ? 'bg-blue-950 text-blue-400 border border-blue-800/50'
                            : row.capTier === 'MID'
                            ? 'bg-amber-950 text-amber-400 border border-amber-800/50'
                            : 'bg-purple-950 text-purple-400 border border-purple-800/50'
                        }`}
                      >
                        {row.capTier}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-200">
                      ₹{row.currentPrice?.toLocaleString('en-IN') || '—'}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-medium">
                      {row.cagr3Y !== null ? (
                        <span className={row.cagr3Y >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          {row.cagr3Y > 0 ? `+${row.cagr3Y}%` : `${row.cagr3Y}%`}
                        </span>
                      ) : (
                        <span className="text-slate-600">N/A</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold bg-emerald-950/20">
                      {row.cagr5Y !== null ? (
                        <span className={row.cagr5Y >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          {row.cagr5Y > 0 ? `+${row.cagr5Y}%` : `${row.cagr5Y}%`}
                        </span>
                      ) : (
                        <span className="text-slate-600">N/A</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-medium">
                      {row.cagr10Y !== null ? (
                        <span className={row.cagr10Y >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          {row.cagr10Y > 0 ? `+${row.cagr10Y}%` : `${row.cagr10Y}%`}
                        </span>
                      ) : (
                        <span className="text-slate-600 text-xs">N/A (&lt;10Y)</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-medium">
                      {row.cagr15Y !== null ? (
                        <span className={row.cagr15Y >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          {row.cagr15Y > 0 ? `+${row.cagr15Y}%` : `${row.cagr15Y}%`}
                        </span>
                      ) : (
                        <span className="text-slate-600 text-xs">N/A (&lt;15Y)</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="text-xs text-slate-400">{row.notes}</span>
                    </td>
                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => onInspectStock(row.symbol)}
                        className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 rounded transition"
                        title="Deep Dive Inspector"
                      >
                        <ArrowUpRight className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredStocks.length > 100 && (
            <div className="p-3 text-center text-xs text-slate-500 bg-slate-950/50 border-t border-slate-800">
              Showing top 100 matching stocks of {filteredStocks.length} records. Refine search filters to narrow selection.
            </div>
          )}
        </div>
      )}

      {/* TAB 2: SECTOR TOP 50 CAGR TABLE */}
      {activeSubTab === 'sectors' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="p-4 bg-slate-950/60 border-b border-slate-800 flex items-center gap-2">
            <Info className="w-4 h-4 text-emerald-400" />
            <span className="text-xs text-slate-300">
              Sector CAGR is computed using the <strong>Top 50 companies by market capitalization</strong> within each sector to ensure blue-chip and high-liquidity compounding fidelity.
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-950/80 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Sector Name</th>
                  <th className="py-3.5 px-3 text-center">Constituents</th>
                  <th className="py-3.5 px-3 text-center">Top 50 Used</th>
                  <th className="py-3.5 px-4 text-right">3Y Median CAGR</th>
                  <th className="py-3.5 px-4 text-right bg-emerald-950/20 text-emerald-400 font-bold">5Y Median CAGR</th>
                  <th className="py-3.5 px-4 text-right">10Y Median CAGR</th>
                  <th className="py-3.5 px-4 text-right">15Y Median CAGR</th>
                  <th className="py-3.5 px-4 text-right">Top 50 Market Cap</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredSectors.map((sec) => (
                  <tr key={sec.sector} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4 font-semibold text-white flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-emerald-400" />
                      {sec.sector}
                    </td>
                    <td className="py-3.5 px-3 text-center font-mono text-slate-400">
                      {sec.totalConstituents}
                    </td>
                    <td className="py-3.5 px-3 text-center font-mono text-emerald-400 font-bold">
                      {sec.top50ConstituentsUsed}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-medium">
                      {sec.cagr3Y !== null ? `+${sec.cagr3Y}%` : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold bg-emerald-950/20 text-emerald-400">
                      {sec.cagr5Y !== null ? `+${sec.cagr5Y}%` : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-medium text-slate-300">
                      {sec.cagr10Y !== null ? `+${sec.cagr10Y}%` : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-medium text-slate-400">
                      {sec.cagr15Y !== null ? `+${sec.cagr15Y}%` : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono text-slate-300">
                      ₹{sec.totalMarketCapCr.toLocaleString('en-IN')} Cr
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: INDUSTRY TOP 25 CAGR TABLE */}
      {activeSubTab === 'industries' && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-sm">
          <div className="p-4 bg-slate-950/60 border-b border-slate-800 flex items-center gap-2">
            <Info className="w-4 h-4 text-emerald-400" />
            <span className="text-xs text-slate-300">
              Industry CAGR evaluates the <strong>Top 25 constituents</strong> by market cap. Where fewer than 25 constituents exist, all available members are used with explicit sample size disclosures.
            </span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-950/80 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Industry Name</th>
                  <th className="py-3.5 px-4">Parent Sector</th>
                  <th className="py-3.5 px-3 text-center">Total</th>
                  <th className="py-3.5 px-3 text-center">Used</th>
                  <th className="py-3.5 px-4">Sample Size Disclosure</th>
                  <th className="py-3.5 px-4 text-right">3Y CAGR</th>
                  <th className="py-3.5 px-4 text-right bg-emerald-950/20 text-emerald-400 font-bold">5Y CAGR</th>
                  <th className="py-3.5 px-4 text-right">10Y CAGR</th>
                  <th className="py-3.5 px-4 text-right">15Y CAGR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredIndustries.map((ind) => (
                  <tr key={ind.industry} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4 font-semibold text-white">
                      {ind.industry}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-400">
                      {ind.sector}
                    </td>
                    <td className="py-3.5 px-3 text-center font-mono text-slate-400">
                      {ind.totalConstituents}
                    </td>
                    <td className="py-3.5 px-3 text-center font-mono text-emerald-400 font-bold">
                      {ind.top25ConstituentsUsed}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`text-xs px-2 py-0.5 rounded ${
                          ind.top25ConstituentsUsed >= 25
                            ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/50'
                            : 'bg-amber-950/60 text-amber-400 border border-amber-800/50'
                        }`}
                      >
                        {ind.sampleSizeDisclosure}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-medium">
                      {ind.cagr3Y !== null ? `+${ind.cagr3Y}%` : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold bg-emerald-950/20 text-emerald-400">
                      {ind.cagr5Y !== null ? `+${ind.cagr5Y}%` : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-medium text-slate-300">
                      {ind.cagr10Y !== null ? `+${ind.cagr10Y}%` : '—'}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-medium text-slate-400">
                      {ind.cagr15Y !== null ? `+${ind.cagr15Y}%` : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
